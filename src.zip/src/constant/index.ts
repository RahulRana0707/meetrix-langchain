import { RoomTemplate } from "../types";

export const ROOM_TEMPLATES: RoomTemplate[] = [
  {
    id: "fire-drill-sim",
    name: "Startup Fire Drill Simulator",
    slug: "fire-drill-sim",
    description:
      "Run through a crisis scenario to stress-test your startup team.",
    topicPrompt:
      "Our user database just leaked. The press found out. Simulate how we should respond.",
    agents: [
      {
        id: "1",
        role: "CEO",
        name: "Ava",
        personality: "decisive",
        metadata: {
          avatar: "👩‍💼",
          color: "#1D4ED8",
          voice: "authoritative",
          tone: "firm",
          toolsAllowed: ["statement-writer"],
          initialThoughts:
            "We must act swiftly and transparently. Prepare a public response.",
        },
      },
      {
        id: "2",
        role: "CTO",
        name: "Raj",
        personality: "technical",
        metadata: {
          avatar: "🧠",
          color: "#2563EB",
          voice: "analytical",
          tone: "factual",
          toolsAllowed: ["incident-reporter"],
          initialThoughts:
            "I’ll need to assess how the breach occurred and if it’s ongoing.",
        },
      },
      {
        id: "3",
        role: "PR Officer",
        name: "Jess",
        personality: "empathetic",
        metadata: {
          avatar: "📣",
          color: "#F472B6",
          voice: "soothing",
          tone: "reassuring",
          toolsAllowed: ["social-monitor"],
          initialThoughts:
            "We need to restore trust. Our tone must acknowledge user fears.",
        },
      },
      {
        id: "4",
        role: "Legal Counsel",
        name: "Marcus",
        personality: "precise",
        metadata: {
          avatar: "⚖️",
          color: "#6B7280",
          voice: "formal",
          tone: "measured",
          toolsAllowed: ["compliance-checker"],
          initialThoughts:
            "What obligations do we have to notify users and regulators?",
        },
      },
    ],
    metadata: {
      tags: ["crisis", "startup", "simulation"],
      difficulty: "advanced",
      useCases: ["founders", "team training"],
      createdBy: "system",
      icon: "🔥",
      themeColor: "#1D4ED8",
      estimatedDuration: "20 mins",
    },
    behavior: {
      isTurnBased: true,
      allowUserInterrupt: true,
      stopConditions: [
        { type: "AGENT_CONSENSUS" },
        { type: "MAX_TURNS", value: 18 },
      ],
      allowAgentMemory: true,
    },
    outputs: {
      generateSummary: true,
      exportFormats: ["pdf", "markdown"],
    },
    version: 1,
    createdAt: "2024-04-19T10:00:00Z",
    updatedAt: "2024-04-19T10:00:00Z",
  },
  {
    id: "tavern-tales",
    name: "Tavernkeeper Roundtable",
    slug: "tavern-tales",
    description:
      "Design a wildly memorable DnD-style fantasy tavern with a cast of eccentric worldbuilders.",
    topicPrompt:
      "We're designing a tavern for adventurers that sits atop a sleeping dragon. Let's flesh it out.",
    agents: [
      {
        id: "1",
        role: "Worldbuilder",
        name: "Thorne",
        personality: "imaginative",
        metadata: {
          avatar: "🌍",
          color: "#9333EA",
          voice: "mystical",
          tone: "poetic",
          toolsAllowed: ["map-maker", "lore-scroll"],
          initialThoughts:
            "Let’s anchor this place in centuries of half-forgotten history.",
        },
      },
      {
        id: "2",
        role: "Tavern Owner",
        name: "Gruntha",
        personality: "gruff",
        metadata: {
          avatar: "🍺",
          color: "#FACC15",
          voice: "gravelly",
          tone: "no-nonsense",
          toolsAllowed: ["menu-gen"],
          initialThoughts:
            "What’s our signature drink? Something with fire, obviously.",
        },
      },
      {
        id: "3",
        role: "Interior Designer",
        name: "Elira",
        personality: "aesthetic",
        metadata: {
          avatar: "🖼️",
          color: "#60A5FA",
          voice: "elegant",
          tone: "refined",
          toolsAllowed: ["sketchpad", "vibe-tester"],
          initialThoughts: "Exposed bone chandeliers or floating torches?",
        },
      },
      {
        id: "4",
        role: "Monster Safety Officer",
        name: "Snargle",
        personality: "anxious",
        metadata: {
          avatar: "⚠️",
          color: "#F87171",
          voice: "nervous",
          tone: "cautious",
          toolsAllowed: ["trap-detector"],
          initialThoughts:
            "Is this dragon going to wake up if someone slams a mug?",
        },
      },
    ],
    metadata: {
      tags: ["fantasy", "creative", "worldbuilding"],
      difficulty: "beginner",
      useCases: ["RPGs", "DMs", "writers"],
      createdBy: "system",
      icon: "🐉",
      themeColor: "#9333EA",
      estimatedDuration: "20-30 mins",
      language: "ENGLISH",
    },
    behavior: {
      isTurnBased: true,
      allowUserInterrupt: true,
      stopConditions: [
        { type: "AGENT_CONSENSUS" },
        { type: "TIME_LIMIT", value: 15 },
      ],
      allowAgentMemory: true,
    },
    outputs: {
      generateSummary: true,
      exportFormats: ["pdf", "markdown"],
    },
    version: 1,
    createdAt: "2024-04-19T10:00:00Z",
    updatedAt: "2024-04-19T10:00:00Z",
  },
  {
    id: "conspiracy-crackdown",
    name: "Conspiracy Crackdown Room",
    slug: "conspiracy-crackdown",
    description:
      "Debunk wild theories with a team of skeptical experts and truth-seekers.",
    topicPrompt:
      "There's a theory that pigeons are government surveillance drones. Let's investigate.",
    agents: [
      {
        id: "1",
        role: "Skeptic Scientist",
        name: "Dr. Lin",
        personality: "rational",
        metadata: {
          avatar: "🔬",
          color: "#3B82F6",
          voice: "calm",
          tone: "analytical",
          toolsAllowed: ["search", "fact-checker"],
          initialThoughts:
            "We’ll begin by tracing the origin and plausibility of this claim.",
        },
      },
      {
        id: "2",
        role: "Historian",
        name: "Jorge",
        personality: "inquisitive",
        metadata: {
          avatar: "📚",
          color: "#8B5CF6",
          voice: "warm",
          tone: "curious",
          toolsAllowed: ["archive-access"],
          initialThoughts:
            "Let’s explore historical patterns in surveillance programs.",
        },
      },
      {
        id: "3",
        role: "Tech Analyst",
        name: "Mira",
        personality: "logical",
        metadata: {
          avatar: "🛠️",
          color: "#F59E0B",
          voice: "neutral",
          tone: "straightforward",
          toolsAllowed: ["sensor-mapper"],
          initialThoughts: "What would it take to turn a pigeon into a drone?",
        },
      },
      {
        id: "4",
        role: "Conspiracy Theorist (Contrarian)",
        name: "Dex",
        personality: "paranoid",
        metadata: {
          avatar: "👁️",
          color: "#EF4444",
          voice: "intense",
          tone: "suspicious",
          toolsAllowed: ["meme-board"],
          initialThoughts: "Open your eyes. Why do pigeons never blink?",
        },
      },
    ],
    metadata: {
      tags: ["conspiracy", "logic", "debate"],
      difficulty: "advanced",
      useCases: ["critical thinking", "education", "entertainment"],
      createdBy: "system",
      icon: "🕵️‍♂️",
      themeColor: "#3B82F6",
      estimatedDuration: "15-25 mins",
      language: "ENGLISH",
    },
    behavior: {
      isTurnBased: true,
      allowUserInterrupt: true,
      stopConditions: [
        { type: "AGENT_CONSENSUS" },
        { type: "MAX_TURNS", value: 20 },
      ],
      allowAgentMemory: true,
    },
    outputs: {
      generateSummary: true,
      exportFormats: ["pdf", "markdown"],
    },
    version: 1,
    createdAt: "2024-04-19T10:00:00Z",
    updatedAt: "2024-04-19T10:00:00Z",
  },
];
